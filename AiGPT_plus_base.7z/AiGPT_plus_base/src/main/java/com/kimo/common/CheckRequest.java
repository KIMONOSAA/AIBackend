package com.kimo.common;

import lombok.Data;

@Data
public class CheckRequest {

        /**
         * id
         */
        private Long id;
}

