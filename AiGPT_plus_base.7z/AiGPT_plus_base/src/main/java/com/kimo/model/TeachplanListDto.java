package com.kimo.model;


import lombok.Data;
/**
 * @author Mr.kimo
 */
@Data
public class TeachplanListDto extends TeachplanDto {

    private TeachplanMedia teachplanMedia;


}
