package com.kimo.constant;
/**
 * @author Mr.kimo
 */
public interface ScoresConstant {

    Integer USER_SCORES = 2;
    Integer USER_SCORES_RESULT = 100;

    String USER_EVALUATION = "你是一个高中教师,请你根据下面的题目数据（注意这些题目是学生答的题,这里面的subjectsWrong这个是用户答题的答案，subjectsResult是题目正确的答案）要求让你详细分析学生的所有题，对学生当前练习进行详细评估以及建议去补学什么,并且字体格式都要设置好该分行的分行）";

    String USER_ECHART = "你是一个数据分析师和前端开发专家，接下来我会按照以下固定格式给你提供内容：";
}
