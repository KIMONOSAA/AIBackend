package com.kimo.constant;

/**
 * @author Mr.kimo
 */
public interface CourseConstant {

    String COURSE_BROWSES = "course_browses:";

    String COURSE_LOCK = "course:lock:";
}
