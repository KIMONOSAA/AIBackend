package com.kimo.constant;
/**
 * @author Mr.kimo
 */
public interface CaffeineConstant {
    String CAFFEINE_COURSE = "caffeine:course:";
    String CAFFEINE_COURSE_MARKET = "market:";
    String REDIS_COURSE_TEACHPLAN = "course:teachplan:";
    String CAFFEINE_USER_LOCKED = "caffeine:user:locked:";
    String CAFFEINE_COURSE_MARKET_LOCKED = "course:market:locked:";

    String CAFFEINE_USER = "caffeine:user:";
}
